<html>
<h1> Hii welcome from ansible </h1>

<pre style="background-color:#ffb6c1;">
<?php
echo  `ifconfig`
?>

</pre>
</html>
